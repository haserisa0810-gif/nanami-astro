import os
import smtplib
from email.mime.text import MIMEText
from email.utils import formatdate
from typing import Any


def get_notify_emails() -> list[str]:
    emails = [
        x.strip()
        for x in (os.getenv("ADMIN_NOTIFY_EMAILS") or "").split(",")
        if x.strip()
    ]
    if not emails:
        single = (
            os.getenv("ADMIN_NOTIFY_EMAIL")
            or os.getenv("ALERT_EMAIL")
            or ""
        ).strip()
        if single:
            emails = [single]
    return emails


def _smtp_config() -> tuple[str, int, str, str, str, str]:
    smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
    smtp_port = int(os.getenv("SMTP_PORT", "587"))
    smtp_user = (os.getenv("SMTP_USERNAME") or os.getenv("MAIL_USERNAME") or "").strip()
    smtp_pass = (os.getenv("SMTP_PASSWORD") or os.getenv("MAIL_PASSWORD") or "").strip()
    from_email = (os.getenv("SMTP_FROM_EMAIL") or smtp_user or "").strip()
    from_name = (os.getenv("SMTP_FROM_NAME") or "星月七海の星読み").strip()
    return smtp_host, smtp_port, smtp_user, smtp_pass, from_email, from_name


def send_mail(subject: str, body: str, to_emails: list[str]) -> bool:
    if not to_emails:
        return False

    smtp_host, smtp_port, smtp_user, smtp_pass, from_email, from_name = _smtp_config()
    if not smtp_user or not smtp_pass or not from_email:
        print("SMTP設定不足のためメール送信スキップ")
        return False

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = f"{from_name} <{from_email}>"
    msg["To"] = ", ".join(to_emails)
    msg["Date"] = formatdate(localtime=True)

    try:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=20) as server:
            server.ehlo()
            if smtp_port in (587, 25):
                server.starttls()
                server.ehlo()
            if smtp_user and smtp_pass:
                server.login(smtp_user, smtp_pass)
            server.sendmail(from_email, to_emails, msg.as_string())
        return True
    except Exception as e:
        print("メール送信エラー:", repr(e))
        return False


def _safe_get(obj: Any, name: str, default: Any = "-") -> Any:
    try:
        value = getattr(obj, name, default)
    except Exception:
        value = default
    return default if value in (None, "") else value


def _order_summary_lines(order: Any) -> list[str]:
    return [
        "■受付番号",
        str(_safe_get(order, "order_code")),
        "",
        "■STORES注文番号",
        str(_safe_get(order, "external_order_ref")),
        "",
        "■お名前",
        str(_safe_get(order, "user_name")),
        "",
        "■メニュー",
        str(_safe_get(order, "menu_id")),
        "",
        "■生年月日",
        str(_safe_get(order, "birth_date")),
        "",
        "■出生時間",
        str(_safe_get(order, "birth_time")),
        "",
        "■出生地",
        str(_safe_get(order, "birth_place")),
        "",
        "■連絡先",
        str(_safe_get(order, "user_contact")),
        "",
        "■相談内容",
        str(_safe_get(order, "consultation_text")),
        "",
        "■管理画面",
        f"https://pay.nanami-astro.com/admin/orders/{_safe_get(order, 'id', '')}",
    ]


def notify_new_order(order: Any) -> bool:
    emails = get_notify_emails()
    if not emails:
        return False

    subject = "【nanami-astro】鑑定依頼が届きました"
    body = "\n".join(["新しい鑑定依頼が届きました。", ""] + _order_summary_lines(order))
    return send_mail(subject, body, emails)


async def notify_line_order_correction(order: Any, correction_text: str | None = None) -> bool:
    emails = get_notify_emails()
    if not emails:
        return False

    subject = f"【nanami-astro】LINE注文修正 {_safe_get(order, 'order_code')}"
    body_lines = [
        "LINE経由で注文修正がありました。",
        "",
        *_order_summary_lines(order),
    ]
    if correction_text:
        body_lines += ["", "■修正内容", str(correction_text)]
    return send_mail(subject, "\n".join(body_lines), emails)


async def notify_new_line_reservation(order: Any) -> bool:
    emails = get_notify_emails()
    if not emails:
        return False

    subject = f"【nanami-astro】LINE予約が入りました {_safe_get(order, 'order_code')}"
    body = "\n".join(["LINE経由の新規予約がありました。", ""] + _order_summary_lines(order))
    return send_mail(subject, body, emails)


async def notify_line_delivery(order: Any, mode: str | None = None) -> bool:
    emails = get_notify_emails()
    if not emails:
        return False

    mode_label = mode or "delivery"
    subject = f"【nanami-astro】LINE納品通知 {_safe_get(order, 'order_code')}"
    body_lines = [
        "LINE納品通知処理が実行されました。",
        "",
        f"mode: {mode_label}",
        "",
        *_order_summary_lines(order),
    ]
    return send_mail(subject, "\n".join(body_lines), emails)


async def notify_delivery_email(order: Any, mode: str | None = None) -> bool:
    user_contact = (_safe_get(order, "user_contact", "") or "").strip()
    customer = getattr(order, "customer", None)
    customer_email = (getattr(customer, "email", None) or "").strip() if customer else ""
    to_email = user_contact if "@" in user_contact and not user_contact.startswith("U") else customer_email
    if not to_email:
        return False

    subject = "【星月七海の星読み】鑑定結果のご案内"
    mode_label = mode or "delivery"
    result_url = f"https://pay.nanami-astro.com/result/{_safe_get(order, 'order_code', '')}"
    body_lines = [
        f"{_safe_get(order, 'user_name', 'お客様')} 様",
        "",
        "鑑定結果のご案内です。",
        f"受付番号: {_safe_get(order, 'order_code')}",
        f"通知種別: {mode_label}",
        "",
        "結果画面はこちら",
        result_url,
    ]
    return send_mail(subject, "\n".join(body_lines), [to_email])
